from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base

# Create FastAPI app
app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database Setup (SQLite)
DATABASE_URL = "sqlite:///./emr.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

# Patient Model
class Patient(Base):
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)

# Create tables automatically
Base.metadata.create_all(bind=engine)

# Routes
@app.get("/")
def home():
    return {"message": "Smart EMR Backend Running"}

@app.post("/patients/")
def create_patient(name: str):
    db = SessionLocal()
    new_patient = Patient(name=name)
    db.add(new_patient)
    db.commit()
    db.refresh(new_patient)
    db.close()
    return new_patient

@app.get("/patients/")
def get_patients():
    db = SessionLocal()
    patients = db.query(Patient).all()
    db.close()
    return patients