package com.neuroweb.smartemr.service;

import com.neuroweb.smartemr.model.Patient;
import com.neuroweb.smartemr.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatient(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
    }

    public List<Patient> searchPatients(String name) {
        return patientRepository.searchByName(name);
    }

    public void deletePatient(Long id) {
        patientRepository.deleteById(id);
    }
}