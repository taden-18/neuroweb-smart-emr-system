package com.neuroweb.smartemr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartemrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartemrApplication.class, args);
	}

}
