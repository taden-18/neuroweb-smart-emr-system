package com.neuroweb.smartemr.controller;

import com.neuroweb.smartemr.model.Visit;
import com.neuroweb.smartemr.service.VisitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/visits")
@CrossOrigin(origins = "*")
public class VisitController {

    @Autowired
    private VisitService visitService;

    // Create a new visit for a patient
    @PostMapping("/patient/{patientId}")
    public Visit createVisit(@PathVariable Long patientId, @RequestBody Visit visit) {
        return visitService.createVisit(patientId, visit);
    }

    // Get all visits for a patient
    @GetMapping("/patient/{patientId}")
    public List<Visit> getPatientVisits(@PathVariable Long patientId) {
        return visitService.getPatientVisits(patientId);
    }

    // Get a single visit by ID
    @GetMapping("/{id}")
    public Visit getVisitById(@PathVariable Long id) {
        return visitService.getVisitById(id);
    }

    // Add transcription to a visit
    @PostMapping("/{id}/transcription")
    public Visit addTranscription(@PathVariable Long id, @RequestBody Map<String, String> payload) {
        String transcription = payload.get("transcription");
        return visitService.addVoiceTranscription(id, transcription);
    }

    // Analyze symptoms for a patient
    @GetMapping("/patient/{patientId}/analyze")
    public Map<String, Object> analyzeSymptoms(@PathVariable Long patientId) {
        return visitService.analyzeSymptoms(patientId);
    }

    // Get BP trends for a patient
    @GetMapping("/patient/{patientId}/trends")
    public Map<String, Object> getBPTrends(@PathVariable Long patientId) {
        return visitService.getBPTrends(patientId);
    }

    // Get today's visit count
    @GetMapping("/today/count")
    public long getTodayVisits() {
        return visitService.getTodayVisits();
    }
}