package com.neuroweb.smartemr.service;

import com.neuroweb.smartemr.model.Patient;
import com.neuroweb.smartemr.model.Visit;
import com.neuroweb.smartemr.repository.PatientRepository;
import com.neuroweb.smartemr.repository.VisitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class VisitService {

    @Autowired
    private VisitRepository visitRepository;

    @Autowired
    private PatientRepository patientRepository;

    // Create a new visit
    public Visit createVisit(Long patientId, Visit visit) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));
        visit.setPatient(patient);
        visit.setVisitDate(LocalDateTime.now());
        return visitRepository.save(visit);
    }

    // Get all visits for a patient
    public List<Visit> getPatientVisits(Long patientId) {
        return visitRepository.findByPatientIdOrderByVisitDateDesc(patientId);
    }

    // Get a single visit by ID
    public Visit getVisitById(Long id) {
        return visitRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Visit not found"));
    }

    // Add transcription to a visit
    public Visit addVoiceTranscription(Long visitId, String transcription) {
        Visit visit = getVisitById(visitId);
        visit.setVoiceTranscription(transcription);
        return visitRepository.save(visit);
    }

    // Analyze recurring symptoms
    public Map<String, Object> analyzeSymptoms(Long patientId) {
        List<Visit> visits = getPatientVisits(patientId);
        Map<String, Integer> symptomCount = new HashMap<>();

        // Count how many times each symptom appears
        for (Visit visit : visits) {
            if (visit.getSymptoms() != null) {
                String[] symptoms = visit.getSymptoms().toLowerCase().split(",");
                for (String s : symptoms) {
                    String symptom = s.trim();
                    if (!symptom.isEmpty()) {
                        symptomCount.put(symptom, symptomCount.getOrDefault(symptom, 0) + 1);
                    }
                }
            }
        }

        // Find recurring symptoms (appear in more than 1 visit)
        List<String> recurring = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : symptomCount.entrySet()) {
            if (entry.getValue() > 1) {
                recurring.add(entry.getKey());
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalVisits", visits.size());
        result.put("symptomFrequency", symptomCount);
        result.put("recurringSymptoms", recurring);

        return result;
    }

    // Get BP trends
    public Map<String, Object> getBPTrends(Long patientId) {
        List<Visit> visits = getPatientVisits(patientId);
        List<Map<String, Object>> readings = new ArrayList<>();

        double totalSystolic = 0;
        double totalDiastolic = 0;
        int count = 0;

        // Take last 10 visits max
        int limit = Math.min(10, visits.size());
        for (int i = 0; i < limit; i++) {
            Visit v = visits.get(i);
            Map<String, Object> reading = new HashMap<>();
            reading.put("date", v.getVisitDate().toString());
            reading.put("systolic", v.getSystolicBP());
            reading.put("diastolic", v.getDiastolicBP());
            reading.put("classification", v.getBpClassification());
            readings.add(reading);

            if (v.getSystolicBP() != null && v.getDiastolicBP() != null) {
                totalSystolic += v.getSystolicBP();
                totalDiastolic += v.getDiastolicBP();
                count++;
            }
        }

        Map<String, Object> trends = new HashMap<>();
        trends.put("readings", readings);
        trends.put("avgSystolic", count > 0 ? totalSystolic / count : 0);
        trends.put("avgDiastolic", count > 0 ? totalDiastolic / count : 0);

        return trends;
    }

    // Get count of today's visits
    public long getTodayVisits() {
        return visitRepository.countTodayVisits();
    }
}