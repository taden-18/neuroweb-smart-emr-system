package com.neuroweb.smartemr.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "visits")
@Data
@NoArgsConstructor
public class Visit {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne
  @JoinColumn(name = "patient_id", nullable = false)
  private Patient patient;

  private LocalDateTime visitDate;

  // Vital signs
  private Integer systolicBP;
  private Integer diastolicBP;
  private Integer heartRate;

  // Clinical data
  @Column(length = 2000)
  private String symptoms;

  @Column(length = 5000)
  private String doctorNotes;

  @Column(length = 5000)
  private String diagnosis;

  @Column(length = 10000)
  private String voiceTranscription;

  private String bpClassification;

  @PrePersist
  protected void onCreate() {
    visitDate = LocalDateTime.now();
    classifyBloodPressure();
  }

  private void classifyBloodPressure() {
    if (systolicBP == null || diastolicBP == null) {
      bpClassification = "No Reading";
      return;
    }

    if (systolicBP > 180 || diastolicBP > 120) {
      bpClassification = "CRITICAL - Emergency";
    } else if (systolicBP >= 140 || diastolicBP >= 90) {
      bpClassification = "Stage 2 Hypertension";
    } else if (systolicBP >= 130 || diastolicBP >= 80) {
      bpClassification = "Stage 1 Hypertension";
    } else if (systolicBP >= 120) {
      bpClassification = "Elevated";
    } else {
      bpClassification = "Normal";
    }
  }
}