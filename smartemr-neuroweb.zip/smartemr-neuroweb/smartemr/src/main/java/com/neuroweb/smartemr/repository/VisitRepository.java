package com.neuroweb.smartemr.repository;

import com.neuroweb.smartemr.model.Visit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface VisitRepository extends JpaRepository<Visit, Long> {

    // Get all visits for a patient, most recent first
    List<Visit> findByPatientIdOrderByVisitDateDesc(Long patientId);

    // Count visits from today
    @Query("SELECT COUNT(v) FROM Visit v WHERE DATE(v.visitDate) = CURRENT_DATE")
    long countTodayVisits();

    // Find visits with high BP
    @Query("SELECT v FROM Visit v WHERE v.systolicBP > 140 OR v.diastolicBP > 90")
    List<Visit> findHighBPVisits();
}