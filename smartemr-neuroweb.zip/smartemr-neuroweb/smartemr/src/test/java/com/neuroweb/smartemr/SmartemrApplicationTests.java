package com.neuroweb.smartemr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartemrApplicationTests {

	@Test
	void contextLoads() {
	}

}
