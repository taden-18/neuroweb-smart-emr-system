package com.hackathon.smartemr.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "visits")
@Data
@NoArgsConstructor
public class Visit {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "patient_id", nullable = false)
  private Patient patient;

  private LocalDateTime visitDate;

  // Vital signs
  private Integer systolicBP;     // Top number
  private Integer diastolicBP;    // Bottom number
  private Integer heartRate;
  private Double temperature;
  private Integer respiratoryRate;
  private Double oxygenSaturation;

  // Clinical data
  @Column(length = 1000)
  private String chiefComplaint;   // Main reason for visit

  @Column(length = 2000)
  private String symptoms;         // Detailed symptoms

  @Column(length = 5000)
  private String doctorNotes;      // Doctor's examination notes

  @Column(length = 5000)
  private String diagnosis;        // Doctor's diagnosis

  @Column(length = 2000)
  private String prescription;     // Prescribed medications

  @Column(length = 1000)
  private String treatmentPlan;    // Follow-up plan

  // Voice transcription (we'll store the raw text)
  @Column(length = 10000)
  private String voiceTranscription;

  // BP Classification (will be auto-calculated)
  private String bpClassification;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @PrePersist
  protected void onCreate() {
    visitDate = LocalDateTime.now();
    createdAt = LocalDateTime.now();
    classifyBloodPressure();
  }

  @PreUpdate
  protected void onUpdate() {
    classifyBloodPressure();
  }

  // Method to classify BP based on guidelines
  private void classifyBloodPressure() {
    if (systolicBP == null || diastolicBP == null) {
      bpClassification = "Not Available";
      return;
    }

    if (systolicBP < 120 && diastolicBP < 80) {
      bpClassification = "Normal";
    } else if (systolicBP < 130 && diastolicBP < 80) {
      bpClassification = "Elevated";
    } else if (systolicBP < 140 || diastolicBP < 90) {
      bpClassification = "Stage 1 Hypertension";
    } else if (systolicBP >= 140 || diastolicBP >= 90) {
      bpClassification = "Stage 2 Hypertension";
    } else if (systolicBP > 180 || diastolicBP > 120) {
      bpClassification = "Hypertensive Crisis - URGENT";
    } else {
      bpClassification = "Unclassified";
    }
  }
}